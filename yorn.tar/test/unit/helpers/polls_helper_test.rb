require 'test_helper'

class PollsHelperTest < ActionView::TestCase
end
