class Poll < ActiveRecord::Base
end
