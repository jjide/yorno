# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Yorn::Application.config.secret_token = 'de0711eac8a4eaa234ca3466357c54ad4c581853ebcf887bc98119a67f9e1fe94886d1fe5c1c0863e01b2fe501fa604288af4f0056198a0d7e32a163693e3afc'
